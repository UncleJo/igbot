from igbot.main import igbot
